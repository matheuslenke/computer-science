//
// Created by mathe on 26/10/2019.
//

#include "Casa.h"

void leCasa(FILE* file, tCasa* casa) {
    fscanf(file," %u ", &casa->n_quartos);
    fscanf(file," %u ", &casa->n_vagas);
    fscanf(file," %u ", &casa->n_pavimentos);
    fscanf(file," %lf ", &casa->area_construida);
    fscanf(file," %u ", &casa->preco_m2_construido);
    fscanf(file," %lf ", &casa->area_livre);
    fscanf(file," %u ", &casa->preco_m2_livre);
}

float calculaPrecoCasa(tCasa* casa) {
    return (float) (casa->preco_m2_construido * casa->area_construida * casa->n_pavimentos +
    casa->preco_m2_livre * casa->area_livre);
}