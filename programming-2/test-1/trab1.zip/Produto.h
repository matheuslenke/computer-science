//
// Created by mathe on 27/10/2019.
//

#ifndef T1_TOPICOS_PROG_PRODUTO_H
#define T1_TOPICOS_PROG_PRODUTO_H

#include "Imovel.h"
#include <stdio.h>
#include <string.h>

typedef struct produto {
    tImovel imovel;
    char categoria[7];
    unsigned int id;
    char proprietario[41];
    float areatotal;
}tProduto;

void leProduto(FILE* file, tProduto* produto);

void alteraProduto(FILE* file, tProduto* produto, char categoria[7]);

void trocaPosicaoProduto(tProduto* produto1, tProduto* produto2);

int comparaMaisCaro(tProduto* produto1, tProduto* produto2);

void removeChar(char *str, char garbage);

int ehCasaEspec(tProduto* produto, float area_limite, float preco_limite);

tProduto refatoraCasa(tProduto* produto, float area_limite, float preco_limite);
#endif //T1_TOPICOS_PROG_PRODUTO_H
