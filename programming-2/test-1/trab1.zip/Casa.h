//
// Created by mathe on 26/10/2019.
//

#ifndef T1_TOPICOS_PROG_CASA_H
#define T1_TOPICOS_PROG_CASA_H

#include <stdio.h>

typedef struct tipocasa {
    unsigned int n_quartos;
    unsigned int n_vagas;
    unsigned int n_pavimentos;
    double area_construida;
    unsigned int preco_m2_construido;
    double area_livre;
    unsigned int preco_m2_livre;
} tCasa;

void leCasa(FILE* file, tCasa* casa);

float calculaPrecoCasa(tCasa* casa);
#endif //T1_TOPICOS_PROG_CASA_H
