//
// Created by mathe on 26/10/2019.
//

#include "Retangulo.h"
#include <stdio.h>

void leRetangulo(FILE* file, tRetangulo* retangulo){
    fscanf(file," %f %f ", &retangulo->lado1,
           &retangulo->lado2);
}

float areaRetangulo(tRetangulo* retangulo) {
    return (retangulo->lado1 * retangulo->lado2);
}