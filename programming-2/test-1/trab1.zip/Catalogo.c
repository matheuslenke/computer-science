//
// Created by mathe on 26/10/2019.
//

#include "Catalogo.h"
#include "Produto.h"

#define DECRESCENTE 0
#define CRESCENTE 1

void leCatalogo(FILE* file, tCatalogo* catalogo) {
    int i = 0;
    char verificavazio[20];
    catalogo->quantidade = 0;

    fscanf(file, "%s ", verificavazio );
    if(feof(file) != 0 ) return;
    rewind(file);

    leProduto(file, &catalogo->produtos[i]);
    catalogo->quantidade++;
    i++;
    while(feof(file) == 0) {
        leProduto(file, &catalogo->produtos[i]);
        i++;
        catalogo->quantidade++;
    }

}

void atualizaCatalogo(FILE* file, tCatalogo* catalogo) {
    tProduto* aux;
    char operacao;
    char categoria[7];
    unsigned int idprocura;
    unsigned int index;
    char verificavazio[20];
    fscanf(file, "%s ", verificavazio );
    if(feof(file) != 0 ) return;
    rewind(file);
    fscanf(file, "%c ", &operacao);
    switch(operacao) {
        case 'i': {
            leProduto(file, &catalogo->produtos[catalogo->quantidade++]);
            break;
        }
        case 'a': {
            fscanf(file, " %[^ \n] ", categoria);
            fscanf(file, " %d ",  &idprocura);
            removeChar(categoria, '\r');
            index = buscaProduto(catalogo, idprocura, catalogo->quantidade);
            alteraProduto(file, &catalogo->produtos[index], categoria);
            break;
        }
        case 'e': {
            tProduto aux;
            fscanf(file, "%d ", &idprocura);
            index = buscaProduto(catalogo, idprocura, catalogo->quantidade);
            for(int i = index; i < catalogo->quantidade; i++) {
                aux = catalogo->produtos[i];
                catalogo->produtos[i] = catalogo->produtos[i+1];
                catalogo->produtos[i+1] = aux;
            }

            catalogo->quantidade -= 1;
            break;
        }
    }
    while( feof(file) == 0){
        fscanf(file, "%c ", &operacao);
        switch(operacao) {
            case 'i': {
                leProduto(file, &catalogo->produtos[catalogo->quantidade++]);
                break;
            }
            case 'a': {
            fscanf(file, " %[^ \n] ", categoria);
            fscanf(file, " %d ",  &idprocura);
            removeChar(categoria, '\r');
                index = buscaProduto(catalogo, idprocura, catalogo->quantidade);
                alteraProduto(file, &catalogo->produtos[index], categoria);
                break;
            }
            case 'e': {
                tProduto aux;
                fscanf(file, "%d ", &idprocura);
                index = buscaProduto(catalogo, idprocura, catalogo->quantidade);
                for(int i = index; i < catalogo->quantidade; i++) {
                    aux = catalogo->produtos[i];
                    catalogo->produtos[i] = catalogo->produtos[i+1];
                    catalogo->produtos[i+1] = aux;
                }

                    catalogo->quantidade -= 1;
                break;
            }
        }
    }
}

int buscaProduto(tCatalogo* catalogo, int id, int qtd) {
    for(int i = 0; i< catalogo->quantidade; i++) {
        if(id == catalogo->produtos[i].id) {
            return i;
        }
    }
}

void OrdenaCatalogoSpec(FILE* arq_spec, tCatalogo* catalogo) {
    int porcentagem, porcentagem2, quantidade1, quantidade2, quantidade3;
    int qtd_argilosos = 0;

    // Ordenação a
    tCatalogo ordenado;
    fscanf(arq_spec, "%d ", &porcentagem);
    if(porcentagem != 100) {
        porcentagem2 = 100 - porcentagem;
    }
    else porcentagem2 = porcentagem;
    quantidade1 = (int)((porcentagem * catalogo->quantidade)/ 100);
    ordenado.quantidade = quantidade1;
    ordenaImoveis(catalogo, comparaMaisCaro, CRESCENTE);
    if(porcentagem != 100) {
        int count = quantidade1;
        for(int i = catalogo->quantidade; i>catalogo->quantidade - (quantidade1 +1); i--) {
            ordenado.produtos[count--] = catalogo->produtos[i];
        }
    }
    else {
        for(int i = 0; i<catalogo->quantidade; i++) {
            ordenado.produtos[i] = catalogo->produtos[i];
        }
    }


    // Ordenação b
    tCatalogo argilosos_ordenado;
    fscanf(arq_spec, "%d ", &porcentagem);
    qtd_argilosos = calculaArgilosos(catalogo);
    if(porcentagem != 100) {
        porcentagem2 = 100 - porcentagem;
    }
    else porcentagem2 = porcentagem;
    quantidade2 = (int)((porcentagem * qtd_argilosos)/ 100);
    argilosos_ordenado.quantidade = quantidade2;
    tCatalogo argilosos;
    argilosos = retornaArgilosos(catalogo);
    argilosos.quantidade = qtd_argilosos;
    ordenaArgilosos(&argilosos, comparaAreaTerreno, DECRESCENTE);

    if(porcentagem2 != 100) {
        int count = quantidade2;
        for(int i = argilosos.quantidade; i>argilosos.quantidade - quantidade2 -1; i--) {
            argilosos_ordenado.produtos[count--] = argilosos.produtos[i];
        }
    }
    else {
        for(int i = 0; i<argilosos.quantidade; i++) {
            argilosos_ordenado.produtos[i] = argilosos.produtos[i];
        }
    }


    //Ordenação c
    float area_limite, preco_limite;
    fscanf(arq_spec, "%f ", &area_limite);
    fscanf(arq_spec, "%f ", &preco_limite);

    tCatalogo lista_c;
    lista_c = casasRefatoradas(catalogo, area_limite, preco_limite);
    ordenaQuartos(&lista_c, comparaQtdQuartos, DECRESCENTE);

    //Lendo os specs para gravar o arquivo saida
    int i,j,k;
    fscanf(arq_spec,"%d ", &i);
    fscanf(arq_spec,"%d ", &j);
    fscanf(arq_spec,"%d ", &k);
    i--;
    j--;
    k--;

    gravarArquivoSaida(&ordenado, &argilosos_ordenado, &lista_c, i, j, k);

}


void ordenaImoveis(tCatalogo* catalogo, int cmp(tProduto*, tProduto*), int ordem){
    tProduto aux;
    // Crescente
    if(ordem == 1) {
        for(int i=0; i < catalogo->quantidade ; i++) {
            for(int j=i+1; j < catalogo->quantidade; j++){
                if(cmp(&catalogo->produtos[i],&catalogo->produtos[j]) >= 0) {
                    if(cmp(&catalogo->produtos[i],&catalogo->produtos[j]) == 0) {
                        if(catalogo->produtos[i].id < catalogo->produtos[j].id) {
                            aux = catalogo->produtos[j];
                            catalogo->produtos[j] = catalogo->produtos[i];
                            catalogo->produtos[i] = aux;
                        }
                    }
                    else {
                        aux = catalogo->produtos[j];
                        catalogo->produtos[j] = catalogo->produtos[i];
                        catalogo->produtos[i] = aux;
                    }
                }
            }
        }
    }

    if(ordem == 0) {
        for(int i=0; i < catalogo->quantidade ; i++) {
            for(int j=i+1; j < catalogo->quantidade; j++){
                if(cmp(&catalogo->produtos[i],&catalogo->produtos[j]) <= 0) {
                    if(cmp(&catalogo->produtos[i],&catalogo->produtos[j]) == 0) {
                        if(catalogo->produtos[i].id < catalogo->produtos[j].id) {
                            aux = catalogo->produtos[j];
                            catalogo->produtos[j] = catalogo->produtos[i];
                            catalogo->produtos[i] = aux;
                        }
                    }
                    else {
                        aux = catalogo->produtos[j];
                        catalogo->produtos[j] = catalogo->produtos[i];
                        catalogo->produtos[i] = aux;
                    }
                }
            }
        }
    }
}

int calculaArgilosos(tCatalogo* catalogo) {
    int qtd_argilosos = 0;
    for(int i = 0; i<= catalogo->quantidade; i++) {
        if(ehArgiloso(&catalogo->produtos[i].imovel.tipo.terreno)) {
            qtd_argilosos++;
        }
    }
    return qtd_argilosos;
}

tCatalogo retornaArgilosos(tCatalogo* catalogo) {
    tCatalogo Aux;
    Aux.quantidade = 0;
    for(int i = 0; i<= catalogo->quantidade; i++) {
        if(ehArgiloso(&catalogo->produtos[i].imovel.tipo.terreno)) {
           Aux.produtos[Aux.quantidade]= catalogo->produtos[i];
           Aux.quantidade++;
        }
    }
    return Aux;
}

void ordenaArgilosos(tCatalogo* catalogo, int cmp(tTerreno*, tTerreno*), int ordem){
    tProduto aux;
    // Crescente
    if(ordem == 1) {
        for(int i=0; i <= catalogo->quantidade ;i++) {
            for(int j=i+1; j <= catalogo->quantidade;j++){
                if(cmp(&catalogo->produtos[i].imovel.tipo.terreno,
                       &catalogo->produtos[j ].imovel.tipo.terreno) >= 0){
                    if(cmp(&catalogo->produtos[i].imovel.tipo.terreno,
                           &catalogo->produtos[j ].imovel.tipo.terreno) == 0) {
                        if(catalogo->produtos[i].id > catalogo->produtos[j].id) {
                            aux = catalogo->produtos[j];
                            catalogo->produtos[j] = catalogo->produtos[i];
                            catalogo->produtos[i] = aux;
                        }
                    }
                    else {
                        aux = catalogo->produtos[j];
                        catalogo->produtos[j] = catalogo->produtos[i];
                        catalogo->produtos[i] = aux;
                    }

                }
            }
        }
    }
    // Decrescente
    else {
        for(int i=0; i <= catalogo->quantidade ;i++) {
            for(int j=i+1; j <= catalogo->quantidade;j++){
                if(cmp(&catalogo->produtos[i].imovel.tipo.terreno,
                       &catalogo->produtos[j ].imovel.tipo.terreno) <= 0){
                    if(cmp(&catalogo->produtos[i].imovel.tipo.terreno,
                           &catalogo->produtos[j ].imovel.tipo.terreno) == 0) {
                        if(catalogo->produtos[i].id > catalogo->produtos[j].id) {
                            aux = catalogo->produtos[j];
                            catalogo->produtos[j] = catalogo->produtos[i];
                            catalogo->produtos[i] = aux;
                        }
                    }
                    else {
                        aux = catalogo->produtos[j];
                        catalogo->produtos[j] = catalogo->produtos[i];
                        catalogo->produtos[i] = aux;
                    }

                }
            }
        }
    }

}

tCatalogo casasRefatoradas(tCatalogo* catalogo, float area_limite, float preco_limite) {
    tCatalogo aux;
    aux.quantidade = 0;
    for(int i = 0; i< catalogo->quantidade; i++) {
        if(ehCasaEspec(&catalogo->produtos[i], area_limite, preco_limite) == 1) {
            aux.produtos[aux.quantidade] = catalogo->produtos[i];
            aux.quantidade++;
        }
    }
    return aux;
}

void ordenaQuartos(tCatalogo* catalogo, int cmp(tImovel*, tImovel*), int ordem) {
    tProduto aux;
    if (ordem == 1) {
        for (int i = 0; i < catalogo->quantidade; i++) {
            for (int j = i +1 ; j < catalogo->quantidade; j++) {
                if (cmp(&catalogo->produtos[i].imovel,
                        &catalogo->produtos[j].imovel) >= 0) {
                    if (cmp(&catalogo->produtos[i].imovel, &catalogo->produtos[j].imovel) ==
                        0) {
                        if (catalogo->produtos[i].id > catalogo->produtos[j].id) {
                            aux = catalogo->produtos[j];
                            catalogo->produtos[j] = catalogo->produtos[i];
                            catalogo->produtos[i] = aux;
                        }
                    }
                    else {
                        aux = catalogo->produtos[j];
                        catalogo->produtos[j] = catalogo->produtos[i];
                        catalogo->produtos[i] = aux;
                    }
                }

            }
        }
    }
    else if (ordem == 0) {
        for (int i = 0; i < catalogo->quantidade; i++) {
            for (int j = i+1; j < catalogo->quantidade; j++) {
                if (cmp(&catalogo->produtos[i].imovel,
                        &catalogo->produtos[j].imovel) <= 0) {
                    if (cmp(&catalogo->produtos[i].imovel, &catalogo->produtos[j].imovel) ==
                        0) {
                        if (catalogo->produtos[i].id < catalogo->produtos[j].id) {
                            aux = catalogo->produtos[j];
                            catalogo->produtos[j] = catalogo->produtos[i];
                            catalogo->produtos[i] = aux;
                        }
                    }
                    else {
                        aux = catalogo->produtos[j];
                        catalogo->produtos[j] = catalogo->produtos[i];
                        catalogo->produtos[i] = aux;
                    }
                }

            }
        }
    }
}


void gravarArquivoSaida (tCatalogo* catalogo1, tCatalogo* catalogo2, tCatalogo* catalogo3, int i,
 int j, int k) {
    FILE* saida;
    saida = fopen("../saida.txt", "w");
    int quantidade1 = catalogo1->quantidade;
    int quantidade2 = catalogo2->quantidade;
    int quantidade3 = catalogo3->quantidade;
    unsigned int saida1 = 0;
    if ((i > catalogo1->quantidade || i < 0) && (j > catalogo2->quantidade || j< 0) && (k >
    catalogo3->quantidade || k< 0)) {
        fprintf(saida, "%u", saida1);
        fprintf(saida, "\n");
        return;
    }

    if(i < catalogo1->quantidade && i>= 0) {
        saida1 += catalogo1->produtos[i].id;
    }
    if(j < catalogo2->quantidade && j>= 0) {
        saida1 += catalogo2->produtos[j].id;
    }
    if(k < catalogo3->quantidade && k>= 0) {
        saida1 += catalogo3->produtos[k].id;
    }
    fprintf(saida,"%u", saida1);
    fprintf(saida, "\n");

    if(catalogo1->quantidade > 0 )
    for(int i = 0; i<catalogo1->quantidade; i++) {
        fprintf(saida,"%u", catalogo1->produtos[i].id);
        if(i != catalogo1->quantidade -1 ) fprintf(saida, ", ");
    }
    fprintf(saida,  "\n");

    for(int i = 0; i<catalogo2->quantidade; i++) {
        fprintf(saida,"%u", catalogo2->produtos[i].id);
        if(i != catalogo2->quantidade -1) fprintf(saida, ", ");
    }
    fprintf(saida, "\n");

    for(int i = 0; i<catalogo3->quantidade; i++) {
        fprintf(saida,"%u", catalogo3->produtos[i].id);
        if(i != catalogo3->quantidade -1) fprintf(saida, ", ");
    }
    fprintf(saida,"\n");

    fclose(saida);
}
