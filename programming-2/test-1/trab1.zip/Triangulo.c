//
// Created by mathe on 26/10/2019.
//

#include "Triangulo.h"
#include <stdio.h>

void leTriangulo(FILE* file, tTriangulo* triangulo){
    fscanf(file," %f %f ", &triangulo->base,
            &triangulo->altura);
}

float areaTriangulo(tTriangulo* triangulo) {
    return ((triangulo->base * triangulo->altura) / 2);
}