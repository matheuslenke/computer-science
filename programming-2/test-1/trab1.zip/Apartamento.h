//
// Created by mathe on 26/10/2019.
//

#ifndef T1_TOPICOS_PROG_APARTAMENTO_H
#define T1_TOPICOS_PROG_APARTAMENTO_H
#include <stdio.h>

typedef struct tipoapartamento {
    unsigned int n_quartos;
    unsigned int n_vagas;
    unsigned int andar;
    float area_construida;
    unsigned int preco_m2_construido;
    char lazer;
    unsigned int total_andares;
} tApartamento;

void leApartamento(FILE* file, tApartamento* apartamento);

float calculaPrecoApto(tApartamento* apto);

#endif //T1_TOPICOS_PROG_APARTAMENTO_H
