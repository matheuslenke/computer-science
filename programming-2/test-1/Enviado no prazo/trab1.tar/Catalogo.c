//
// Created by mathe on 26/10/2019.
//

#include "Catalogo.h"
#include "Produto.h"

#define DECRESCENTE 1
#define CRESCENTE 0

void leCatalogo(FILE* file, tCatalogo* catalogo) {
    int i = 0;
    catalogo->quantidade = 0;
    do {
        leProduto(file, &catalogo->produtos[i]);
        i++;
        catalogo->quantidade++;
    }while(feof(file) == 0);

}

void atualizaCatalogo(FILE* file, tCatalogo* catalogo) {
    tProduto* aux;
    char operacao;
    char categoria[7];
    unsigned int idprocura;
    unsigned int index;
    do {
        fscanf(file, "%c ", &operacao);
        //fgetc(file);
        switch(operacao) {
            case 'i': {
                leProduto(file, &catalogo->produtos[catalogo->quantidade++]);
                break;
            }
            case 'a': {
            fscanf(file, " %[^ \n] ", categoria);
            fscanf(file, " %d ",  &idprocura);
            removeChar(categoria, '\r');
                index = buscaProduto(catalogo, idprocura, catalogo->quantidade);
                alteraProduto(file, &catalogo->produtos[index], categoria);
                break;
            }
            case 'e': {
                fscanf(file, "%d ", &idprocura);
                index = buscaProduto(catalogo, idprocura, catalogo->quantidade);
                for(index; index < catalogo->quantidade-1; index++) {
                    trocaPosicaoProduto( &catalogo->produtos[index], &catalogo->produtos[index +
                    1]);
                }
                    catalogo->quantidade -= 1;
                break;
            }
        }
    } while( feof(file) == 0);
}

int buscaProduto(tCatalogo* catalogo, int id, int qtd) {
    for(int i = 0; i< catalogo->quantidade; i++) {
        if(id == catalogo->produtos[i].id) {
            return i;
        }
    }
}

void OrdenaCatalogoSpec(FILE* arq_spec, tCatalogo* catalogo) {
    int porcentagem, quantidade1, quantidade2, quantidade3;
    int qtd_argilosos = 0;

    // Ordenação a
    tCatalogo ordenado;
    fscanf(arq_spec, "%d ", &porcentagem);
    quantidade1 = (int)(porcentagem * catalogo->quantidade)/ 100;
    ordenado.quantidade = quantidade1;
    ordenaImoveis(catalogo, comparaMaisCaro, CRESCENTE);
    for(int i = 0; i<ordenado.quantidade; i++) {
        ordenado.produtos[i] = catalogo->produtos[i];
    }

    // Ordenação b
    tCatalogo argilosos_ordenado;
    fscanf(arq_spec, "%d ", &porcentagem);
    qtd_argilosos = calculaArgilosos(catalogo);
    quantidade2 = (int)(porcentagem * qtd_argilosos)/ 100;
    argilosos_ordenado.quantidade = quantidade2;
    tCatalogo argilosos;
    argilosos = retornaArgilosos(catalogo);
    ordenaArgilosos(&argilosos, comparaAreaTerreno, DECRESCENTE);

    for(int i = 0; i<argilosos_ordenado.quantidade; i++) {
        argilosos_ordenado.produtos[i] = argilosos.produtos[i];
    }

    //Ordenação c
    float area_limite, preco_limite;
    fscanf(arq_spec, "%f ", &area_limite);
    fscanf(arq_spec, "%f ", &preco_limite);

    tCatalogo lista_c;
    lista_c = casasRefatoradas(catalogo, area_limite, preco_limite);
    ordenaQuartos(&lista_c, comparaQtdQuartos, DECRESCENTE);

    //Lendo os specs para gravar o arquivo saida
    int i,j,k;
    fscanf(arq_spec,"%d ", &i);
    fscanf(arq_spec,"%d ", &j);
    fscanf(arq_spec,"%d ", &k);
    i--;
    j--;
    k--;

    gravarArquivoSaida(&ordenado, &argilosos_ordenado, &lista_c, i, j, k);

}


void ordenaImoveis(tCatalogo* catalogo, int cmp(tProduto*, tProduto*), int ordem){
    tProduto aux;

    if(ordem == 1) {
        for(int i=0; i < catalogo->quantidade ;i++) {
            for(int j=0; j < catalogo->quantidade - i - 1;j++){
                if(cmp(&catalogo->produtos[j],&catalogo->produtos[j + 1]) >= 0) {
                    if(cmp(&catalogo->produtos[j],&catalogo->produtos[j + 1]) == 0) {
                    if(catalogo->produtos[j].id > catalogo->produtos[j+1].id) {
                        aux = catalogo->produtos[j+1];
                        catalogo->produtos[j+1] = catalogo->produtos[j];
                        catalogo->produtos[j] = aux;
                    }
                }
                    else {
                        aux = catalogo->produtos[j+1];
                        catalogo->produtos[j+1] = catalogo->produtos[j];
                        catalogo->produtos[j] = aux;
                    }
                }
            }
        }
    }
    else if(ordem == 0) {
        for(int i=0; i < catalogo->quantidade ;i++) {
            for(int j=0; j < catalogo->quantidade - i - 1;j++){
                if(cmp(&catalogo->produtos[j+1],&catalogo->produtos[j]) <= 0) {
                    if(cmp(&catalogo->produtos[j+1],&catalogo->produtos[j]) == 0) {
                    if(catalogo->produtos[j+1].id > catalogo->produtos[j].id) {
                        aux = catalogo->produtos[j+1];
                        catalogo->produtos[j+1] = catalogo->produtos[j];
                        catalogo->produtos[j] = aux;
                    }
                }
                    else {
                        aux = catalogo->produtos[j+1];
                        catalogo->produtos[j+1] = catalogo->produtos[j];
                        catalogo->produtos[j] = aux;
                    }
                }
            }
        }
    }
}

int calculaArgilosos(tCatalogo* catalogo) {
    int qtd_argilosos;
    for(int i = 0; i< catalogo->quantidade; i++) {
        if(ehArgiloso(&catalogo->produtos[i].imovel.tipo.terreno)) {
            qtd_argilosos ++;
        }
    }
    return qtd_argilosos;
}

tCatalogo retornaArgilosos(tCatalogo* catalogo) {
    tCatalogo Aux;
    Aux.quantidade = 0;
    for(int i = 0; i< catalogo->quantidade; i++) {
        if(ehArgiloso(&catalogo->produtos[i].imovel.tipo.terreno)) {
           Aux.produtos[Aux.quantidade]= catalogo->produtos[i];
           Aux.quantidade++;
        }
    }
    return Aux;
}

void ordenaArgilosos(tCatalogo* catalogo, int cmp(tTerreno*, tTerreno*), int ordem){
    tProduto aux;
    if(ordem == 1) {
        for(int i=0; i < catalogo->quantidade ;i++) {
            for(int j=0; j < catalogo->quantidade - i - 1;j++){
                if(cmp(&catalogo->produtos[j].imovel.tipo.terreno,
                       &catalogo->produtos[j + 1].imovel.tipo.terreno) == 1){
                    aux = catalogo->produtos[j+1];
                    catalogo->produtos[j+1] = catalogo->produtos[j];
                    catalogo->produtos[j] = aux;

                }
            }
        }
    }
    else {
        for(int i=0; i < catalogo->quantidade ;i++) {
            for(int j=0; j < catalogo->quantidade - i - 1;j++){
                if(cmp(&catalogo->produtos[j].imovel.tipo.terreno,
                       &catalogo->produtos[j + 1].imovel.tipo.terreno) == 1){
                    aux = catalogo->produtos[j+1];
                    catalogo->produtos[j+1] = catalogo->produtos[j];
                    catalogo->produtos[j] = aux;
                }
            }
        }

    }

}

tCatalogo casasRefatoradas(tCatalogo* catalogo, float area_limite, float preco_limite) {
    tCatalogo aux;
    aux.quantidade = 0;
    for(int i = 0; i< catalogo->quantidade; i++) {
        if(ehCasaEspec(&catalogo->produtos[i], area_limite, preco_limite)) {
            aux.produtos[i] = refatoraCasa(&catalogo->produtos[i], area_limite, preco_limite);
            aux.quantidade++;
        }
    }
    return aux;
}

void ordenaQuartos(tCatalogo* catalogo, int cmp(tImovel*, tImovel*), int ordem) {
    tProduto aux;
    if (ordem == 1) {
        for (int i = 0; i < catalogo->quantidade; i++) {
            for (int j = 0; j < catalogo->quantidade - i - 1; j++) {
                if (cmp(&catalogo->produtos[j].imovel,
                        &catalogo->produtos[j + 1].imovel) >= 0)
                    if (cmp(&catalogo->produtos[j].imovel, &catalogo->produtos[j + 1].imovel) ==
                        0) {
                        if (catalogo->produtos[j].id > catalogo->produtos[j + 1].id) {
                            aux = catalogo->produtos[j + 1];
                            catalogo->produtos[j + 1] = catalogo->produtos[j];
                            catalogo->produtos[j] = aux;
                        }
                    } else {
                        aux = catalogo->produtos[j + 1];
                        catalogo->produtos[j + 1] = catalogo->produtos[j];
                        catalogo->produtos[j] = aux;
                    }


            }
        }
    }
    else if (ordem == 0) {
        for (int i = 0; i < catalogo->quantidade; i++) {
            for (int j = 0; j < catalogo->quantidade - i - 1; j++) {
                if (cmp(&catalogo->produtos[j].imovel,
                        &catalogo->produtos[j + 1].imovel) <= 0)
                    if (cmp(&catalogo->produtos[j].imovel, &catalogo->produtos[j + 1].imovel) ==
                        0) {
                        if (catalogo->produtos[j].id > catalogo->produtos[j + 1].id) {
                            aux = catalogo->produtos[j + 1];
                            catalogo->produtos[j + 1] = catalogo->produtos[j];
                            catalogo->produtos[j] = aux;
                        }
                    } else {
                        aux = catalogo->produtos[j + 1];
                        catalogo->produtos[j + 1] = catalogo->produtos[j];
                        catalogo->produtos[j] = aux;
                    }


            }
        }
    }
}

void gravarArquivoSaida (tCatalogo* catalogo1, tCatalogo* catalogo2, tCatalogo* catalogo3, int i,
 int j, int k) {
    FILE* saida;
    saida = fopen("../saida2.txt", "w");

    unsigned int saida1;
    saida1 =(catalogo1->produtos[i].id + catalogo2->produtos[j].id +
                   catalogo3->produtos[k].id) ;
    fprintf(saida,"%u", saida1);
    fprintf(saida, "\n");

    for(int i = 0; i<catalogo1->quantidade; i++) {
        fprintf(saida,"%u;", catalogo1->produtos[i].id);
    }
    fprintf(saida,  "\n");

    for(int i = 0; i<catalogo2->quantidade; i++) {
        fprintf(saida,"%u;", catalogo2->produtos[i].id);
    }
    fprintf(saida, "\n");

    for(int i = 0; i<catalogo3->quantidade; i++) {
        fprintf(saida,"%u;", catalogo3->produtos[i].id);
    }
    fprintf(saida,"\n");

    fclose(saida);
}
