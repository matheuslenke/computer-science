#include <stdio.h>
#include "Catalogo.h"
#include <stdlib.h>
#include <stdlib.h>
#include <string.h>

int main() {

    //Lendo o catalogo
    tCatalogo catalogo;
    FILE* arq_catalogo = fopen("../catalogo.txt",
            "r");
    if (!arq_catalogo) {
        printf("falhou em abrir catalogo.txt");
        exit(1);
    }
    leCatalogo(arq_catalogo, &catalogo);

    //Atualizando o catalogo
    FILE* arq_atual = fopen("../atual.txt",
            "r");
    if (!arq_atual) {
        printf("falhou em abrir atual.txt");
        exit(1);
    }
    atualizaCatalogo(arq_atual, &catalogo);


    FILE* arq_spec = fopen("../espec.txt",
            "r");
    if (!arq_spec) {
        printf("falhou em abrir spec.txt");
        exit(1);
    }
    OrdenaCatalogoSpec(arq_spec, &catalogo);


    return 0;
}