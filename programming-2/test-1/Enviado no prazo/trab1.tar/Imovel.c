//
// Created by mathe on 26/10/2019->
//

#include "Imovel.h"
#include <stdio.h>
#include <string.h>


void leImovel(FILE* file, tImovel* imovel, char* categoria) {
    strcpy(imovel->categoria,categoria);

    if (strcmp(categoria, "casa") == 0) {
    leCasa(file, &imovel->tipo.casa);
    imovel->preco = calculaPrecoImovel(imovel,categoria);
    return;
    }
    if (strcmp(categoria, "apto") == 0) {
        leApartamento(file, &imovel->tipo.apartamento);
        imovel->preco = calculaPrecoImovel(imovel,categoria);
        return;
    }
    if (strcmp(categoria, "triang") == 0 ||
    strcmp(categoria, "retang") == 0 ||
    strcmp(categoria, "trapez") == 0) {
        leTerreno(file, &imovel->tipo.terreno, imovel->categoria);
        imovel->preco = calculaPrecoImovel(imovel,categoria);
    return;
    }
}

float calculaPrecoImovel(tImovel* imovel, char* categoria) {

    if (strcmp(categoria, "casa") == 0) {
       return calculaPrecoCasa(&imovel->tipo.casa);
    }
    if (strcmp(categoria, "apto") == 0) {
         return calculaPrecoApto(&imovel->tipo.apartamento);

    }
    if (strcmp(categoria, "triang") == 0 ||
        strcmp(categoria, "retang") == 0 ||
        strcmp(categoria, "trapez") == 0) {
        return calculaPrecoTerreno(&imovel->tipo.terreno);
    }
}

int comparaPrecoImovel(tImovel* imovel1, tImovel* imovel2){
    if(imovel1->preco < imovel2->preco) {
        return 1;
    }
    if(imovel1->preco > imovel2->preco) {
        return -1;
    }
    if(imovel1->preco == imovel2->preco) {
        return 0;
    }
}

int comparaQtdQuartos(tImovel* imovel1, tImovel* imovel2){
    if(imovel1->tipo.casa.n_quartos < imovel2->tipo.casa.n_quartos) {
        return 1;
    }
    if(imovel1->tipo.casa.n_quartos > imovel2->tipo.casa.n_quartos) {
        return -1;
    }
    if(imovel1->tipo.casa.n_quartos == imovel2->tipo.casa.n_quartos) {
        return 0;
    }
}




