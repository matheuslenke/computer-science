//
// Created by mathe on 26/10/2019.
//

#ifndef T1_TOPICOS_PROG_TERRENO_H
#define T1_TOPICOS_PROG_TERRENO_H

#include "Triangulo.h"
#include "Retangulo.h"
#include "Trapezio.h"
#include <stdio.h>

typedef union formato {
    tTriangulo Triangulo;
    tRetangulo Retangulo;
    tTrapezio Trapezio;
}tFormato;

typedef struct tipoterreno {
    char tipo_de_solo;
    unsigned int preco_m2_terreno;
    tFormato formato;
    char categoria[7];
    float area;
}tTerreno;

void leTerreno(FILE* file, tTerreno* terreno,  char* categoria);

float calculaPrecoTerreno(tTerreno* terreno);

int ehArgiloso(tTerreno* terreno);

int comparaAreaTerreno(tTerreno* terreno1, tTerreno* terreno2);

#endif //T1_TOPICOS_PROG_TERRENO_H
