//
// Created by mathe on 26/10/2019.
//

#include "Apartamento.h"


void leApartamento(FILE* file, tApartamento* apartamento) {
    fscanf(file, " %u ", &apartamento->n_quartos);
    fscanf(file, " %u ", &apartamento->n_vagas);
    fscanf(file, " %u ", &apartamento->andar);
    fscanf(file, " %f ", &apartamento->area_construida);
    fscanf(file, " %u ", &apartamento->preco_m2_construido);
    fscanf(file, " %c ", &apartamento->lazer);
    fscanf(file, " %u ", &apartamento->total_andares);
}

void imprimeApartamento(tApartamento* apartamento) {
    printf("Apartamento: \n qtos: %u vagas: %u andar: %u \n "
           "area const: %lf preco m2: %u lazer: %c andares: %u", apartamento->n_quartos,
           apartamento->n_vagas, apartamento->andar, apartamento->area_construida,
           apartamento->preco_m2_construido, apartamento->lazer, apartamento->total_andares);
}

float calculaPrecoApto(tApartamento* apto) {
    float aux;
    switch(apto->lazer) {
        case 'S': {
            aux = (float) ( apto->preco_m2_construido * apto->area_construida * (0,9 +
            (apto->andar/ (float)apto->total_andares)) * 1.15 );
        break;
        }
        case 'N': {
            aux = (float) ( apto->preco_m2_construido * apto->area_construida * (0,9 +
            (apto->andar/ (float)apto->total_andares)) * 1 );
            break;
        }
    }
    return aux;
}