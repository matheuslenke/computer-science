//
// Created by mathe on 26/10/2019.
//

#ifndef T1_TOPICOS_PROG_IMOVEL_H
#define T1_TOPICOS_PROG_IMOVEL_H

#include "Casa.h"
#include "Apartamento.h"
#include "Terreno.h"

typedef union tipo {
    tCasa casa;
    tApartamento apartamento;
    tTerreno terreno;
}tipo_imovel;

typedef struct tipoimovel{
    tipo_imovel tipo;
    char categoria[7];
    float preco;
} tImovel;

void leImovel(FILE* file, tImovel* imovel, char* categoria);

int comparaPrecoImovel(tImovel* imovel1, tImovel* imovel2);

float calculaPrecoImovel(tImovel* imovel, char* categoria);

int comparaQtdQuartos(tImovel* imovel1, tImovel* imovel2);

int ehCasaEspecifica(tImovel* imovel, float area_limite, float preco_limite);

#endif //T1_TOPICOS_PROG_IMOVEL_H
