//
// Created by mathe on 26/10/2019.
//

#ifndef T1_TOPICOS_PROG_RETANGULO_H
#define T1_TOPICOS_PROG_RETANGULO_H

#include <stdio.h>

typedef struct retangulo {
    float lado1, lado2;
}tRetangulo;

void leRetangulo(FILE* file, tRetangulo* retangulo);

float areaRetangulo(tRetangulo* retangulo);
#endif //T1_TOPICOS_PROG_RETANGULO_H
