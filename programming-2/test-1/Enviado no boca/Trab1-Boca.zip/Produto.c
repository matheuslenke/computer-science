//
// Created by mathe on 27/10/2019.
//

#include "Produto.h"
#include "Imovel.h"

void removeChar(char *str, char garbage) {

    char *src, *dst;
    for (src = dst = str; *src != '\0'; src++) {
        *dst = *src;
        if (*dst != garbage) dst++;
    }
    *dst = '\0';
}

void leProduto(FILE* file, tProduto* produto) {
    char stop;
    fscanf(file, "%[^\n] ", produto->categoria);
    //stop = fgetc(file);
    removeChar(produto->categoria, '\r');
    fscanf(file, " %u ", &produto->id);
    //stop = fgetc(file);
    fscanf(file, "%[^\n] ", produto->proprietario);
    removeChar(produto->proprietario, '\r');

    leImovel(file, &produto->imovel, produto->categoria);
    //fscanf(file, " %[^\n] ", stop);
  //  calculaPrecoProduto(produto, produto->categoria);
}

void ImprimeProduto(tProduto* produto) {

}

void alteraProduto(FILE* file, tProduto* produto, char* categoria) {
    strcpy(produto->categoria, categoria);

    fscanf(file, "%[^\n] ", produto->proprietario);
    removeChar(produto->proprietario, '\r');
    leImovel(file, &produto->imovel, categoria);

}

void trocaPosicaoProduto(tProduto* produto1, tProduto* produto2) {
    tProduto* aux;
    aux = produto1;
    produto1 = produto2;
    produto2 = aux;
}

int comparaMaisCaro(tProduto* produto1, tProduto* produto2){
    int aux;
    aux = comparaPrecoImovel(&produto1->imovel, &produto2->imovel);
    if(aux == 0) {
        if(produto1->id > produto2->id){
            aux = 1;
        }
        else aux = -1;
    }
    return aux;
}


int ehProdutoEspec(tProduto* produto, float area_limite, float preco_limite) {
    if(ehCasaEspecifica(&produto->imovel, area_limite, preco_limite ) == 1) {
        return 1;
    }
    else return 0;
}

int comparaQtdQuartosProduto(tProduto* produto1, tProduto* produto2, int ordem) {
    int aux = comparaQtdQuartos(&produto1->imovel, &produto2->imovel);
    if (aux == 0) {
        if(ordem == 0) {
            if(produto1->id > produto2->id) {
                aux = 1;
            }
            else aux = -1;
        }
        else {
            if(produto1->id < produto2->id) {
                aux = 1;
            }
            else aux = -1;
        }

    }
    return aux;
}

tProduto refatoraCasa(tProduto* produto, float area_limite, float preco_limite) {
    tProduto aux;
        if(strcmp(produto->categoria, "casa") == 0) {
            if(produto->imovel.tipo.casa.area_construida >= area_limite
               && produto->imovel.preco <= preco_limite) {
                aux = *produto;
            }
        }
    return aux;
}