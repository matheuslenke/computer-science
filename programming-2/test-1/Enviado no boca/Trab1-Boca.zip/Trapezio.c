//
// Created by mathe on 26/10/2019.
//

#include "Trapezio.h"
#include <stdio.h>

void leTrapezio(FILE* file, tTrapezio* trapezio){
fscanf(file," %f %f %f ", &trapezio->base1,
        &trapezio->base2,
        &trapezio->altura);
}

float areaTrapezio(tTrapezio* trapezio) {
    return (float) (((trapezio->base1 + trapezio->base2)* trapezio->altura) /2.0);
}